import React from "react";
function SubNav(){
    return(
        // <div>
            <div className="subnav1">
                {/* <div> */}
                <div>
                <h1 className="sub2">Canopy is Amazon, Curated.</h1>
                </div>
                <hr id="hr"/>
                
                <div>
                    <span className="sub3">
                        <h3 id="bor1" className="sub4">Learn about canopy</h3>
                       
                    
                        
                        <h3 id="bor2" className="sub4">Find great gifts</h3>
                    
                    
                        <h3 className="sub4">Join to save products</h3>
                    </span>
                </div>

               
                
                {/* </div> */}
            </div>
        
        //   </div>
    )
}
export default SubNav;